#Write a program to check if a person is eligible to vote or not
i=0
while (i!=1):
   a=int(input("enter your age"))

   if(a>=18):
      print("eligible for vote ")
   else:
      print("not eligible for vote")
   i=int(input("for exit press 1 & for continue press 2"))

input()   
