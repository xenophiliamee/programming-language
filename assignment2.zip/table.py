#multipication table is
a=int (input("enter a number to print table : "))
i=1
while (i<=10):
     print("",a,"x","",i,"",a*i)
     i+=1
input()     
