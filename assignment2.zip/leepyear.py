#leep year
a=int(input("enter your number"))
if(a % 4 == 0) :
    print(a,"leep year")
else :
     print(a,"not a leep year")

input()
