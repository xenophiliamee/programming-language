while True:
    n=input('enter any integer(press x to exit):')
    if n =='x':
        break
input()
