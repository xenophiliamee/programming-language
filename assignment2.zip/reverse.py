
a=int (input("enter a number to print reverse : "))
while (a>=0):
      print(a)
      a-=1
input()
