#Write a program to find the largest number in a given range of number ( Accept two number
a=int(input("enter first your number"))
b=int(input("enter second your number"))
if(a>b):
  print(a,"is largest")
else:
    print(b,"is largest")
input()    
