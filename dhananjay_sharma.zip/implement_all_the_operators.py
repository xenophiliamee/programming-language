# Program to implement all the operators for integers and floats
a=int(input("enter a interger number"))
b=int(input("enter a interger number"))
c=float(input("enter a floating  number"))
d=float(input("enter a floatig number"))
#interger add
print(a+b)
#floating add
print(c+d)
#interger multipication
print(a*b)
#FLOATIG MULTIPICATION
print(c*d)
#interger divided
print(a/b)
#floating divided
print(c/d)
#interger calculate power
print(a**b)

