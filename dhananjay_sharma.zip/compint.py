#compound interest
#dhananjay_shaema
p=int(input("enter principle"))
r=int(input("enter rate"))
t=int(input("enter time"))
CI = p * pow ( (1 + r / 100), t)
print(CI)
input()
