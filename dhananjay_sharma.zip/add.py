#dhanajay_sharma
print("Python program to add two numbers")
a=int(input("enter your number a= "))
b=int (input("enter your number b= "))
print('a=',a,'+','b=',b,'\n',a+b)
input()
