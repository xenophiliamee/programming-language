#simple interst
p=float(input("enter pricipal"))
r=float(input("enter rate"))
t=float(input("enter time"))
SI=p*r*t/100 
print("simple intrest is ",SI)
input()
