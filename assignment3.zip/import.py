import AirExp

a=AirExp.add(6,5,8)
print('addition is:',a)
s=AirExp.sub(8,9)
print('substraction is:',s)
m=AirExp.mul(10,11)
print('multiplicition is:',m)
b=AirExp.avg(9,88,7,6)
print('average is:',b)
input()
