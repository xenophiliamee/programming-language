#Write a Python program to print the square of all numbers from 1 to 20
def square():
    n=0
    for i in range(1,21):
        n=i**2
        print(n)

square()
input()
