#Write a Python program to print every third number from a list of numbers.
def list_th():
    list(range(0,30))
    for i in range(0,100,3):
        print(i)

list_th()
